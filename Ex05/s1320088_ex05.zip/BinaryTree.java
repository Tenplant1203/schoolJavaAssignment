public class BinaryTree extends OrderedTree {
  public BinaryTree() {
    System.err.println("BinaryTree");
  }
}
