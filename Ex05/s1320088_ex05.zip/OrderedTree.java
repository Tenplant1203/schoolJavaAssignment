public class OrderedTree extends RootedTree {
  public OrderedTree() {
    System.err.println("OrderedTree");
  }
}
