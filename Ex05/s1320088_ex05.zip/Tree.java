public class Tree {
  public Tree() {
    System.err.println("Tree");
  }
}
