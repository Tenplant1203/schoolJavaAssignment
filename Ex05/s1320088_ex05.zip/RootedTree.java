public class RootedTree extends Tree {
  public RootedTree() {
    System.err.println("RootedTree");
  }
}
