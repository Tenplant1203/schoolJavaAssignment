class ConstructorChainApplication {
  public static void main(String[] args) {
    BinaryTree BinaryTree = new BinaryTree();
  }
}
